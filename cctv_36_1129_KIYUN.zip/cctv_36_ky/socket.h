#ifndef SOCKET_H
#define SOCKET_H

#include <QSslSocket>


#endif // SOCKET_H
